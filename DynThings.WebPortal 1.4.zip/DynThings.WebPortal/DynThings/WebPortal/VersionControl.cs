﻿namespace DynThings.WebPortal
{
    internal static class VersionControl
    {
         public static double GetVersion()
        {
            double version = 1.4;

            return version;
        }
    }
}