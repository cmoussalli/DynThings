﻿/////////////////////////////////////////////////////////////////
// Created by : Caesar Moussalli                               //
// TimeStamp  : 31-1-2016                                      //
// Content    : Handel the API EndPoint IOs Actions            //
// Notes      :                                                //
//                                                             //
/////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DynThings.Data.Models;



namespace DynThings.WebPortal.Controllers
{
    public class APIEndPointIOsController : ApiController
    {
        private DynThingsEntities db = new DynThingsEntities();

     

        


    }
}
