﻿namespace DynThings.WebPortal
{
    internal static class VersionControl
    {
        public static float GetVersion()
        {
            float version = 1;

            return version;
        }
    }
}